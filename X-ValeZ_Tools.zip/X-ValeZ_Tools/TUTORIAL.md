# Tutorial

## 1. API key

Simpan key di `config.py`:

```python
VEXO_API_KEY = "ISI_API_KEY_DI_SINI"
```

Untuk JavaScript, simpan di `javascript/config.js`.

## 2. Python

Semua request memakai client bersama di `lib/client.py`. Parameter otomatis di-URL-encode. Timeout default 25 detik. HTTP error, koneksi gagal, response non-JSON, dan `status: false` ditangani sebagai pesan error yang terbaca.

## 3. Downloader

`tt-downloaded.py` menerima URL TikTok dan meminta data downloader. `yt-downloaded.py` menerima URL YouTube dan meminta data audio. `all-downloaded.py` memakai endpoint all-in-one.

## 4. Islamic

`al-quran.py` menerima nomor surah opsional. `jadwal-sholat.py` meminta kota. `asmaul-husna.py` tidak membutuhkan parameter. `doa-harian.py` dan `hadits-arbain.py` menerima filter opsional.

## 5. Search dan tools

`google-search.py`, `youtube-search.py`, `dictionary.py`, `country-info.py`, `github-info.py`, `weather.py`, `translate.py`, `auto-translate.py`, `tiktok-transcript.py`, `ssweb.py`, dan `url-shortener.py` langsung meminta input yang diperlukan.

## 6. Berita

`news.py` menyediakan pilihan sumber yang tersedia di dokumentasi endpoint. Pilih nomor lalu hasil ditampilkan dalam panel adaptif.

## 7. AI

`ai-chat.py` mengirim teks ke endpoint AI dan menampilkan response JSON lengkap.

## 8. Rate limit

Kuota standar yang tertulis pada dokumentasi adalah 100 request per key dan reset setiap 5 jam. HTTP 429 ditampilkan sebagai error yang bisa dibaca.

## 9. Praktik aman

Jangan commit `config.py` yang sudah berisi key pribadi. Hindari menaruh key pada frontend browser. Gunakan CLI/backend.
