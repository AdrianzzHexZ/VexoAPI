# X-ValeZ Tools

Developer: Adrianzz

Kumpulan CLI Python dan JavaScript dengan UI terminal berwarna, panel adaptif, validasi input, timeout request, penanganan HTTP error, dan output JSON yang rapi.

## Struktur

- `run.py` menu utama
- `config.py` konfigurasi API key Python
- `lib/` client dan UI bersama
- `javascript/` contoh Node.js
- `requirements.txt` dependency Python
- `TUTORIAL.md` panduan penggunaan

## Setup Python

Buka `config.py`, isi:

```python
VEXO_API_KEY = "ISI_API_KEY_DI_SINI"
```

Lalu jalankan:

```bash
python run.py
```

## Jalankan satu tool

```bash
python tt-downloaded.py
python al-quran.py
python weather.py
```

## Setup Node.js

Buka `javascript/config.js`, isi `VEXO_API_KEY`, lalu:

```bash
node javascript/weather.js Jakarta
node javascript/tt-downloader.js "https://www.tiktok.com/..."
node javascript/al-quran.js 1
```

API key dipakai dari backend/CLI config, bukan frontend browser.
